package com.hanul.iot;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import employee.EmployeeServiceImpl;

@Controller
public class EmployeeController {
	@Autowired private EmployeeServiceImpl service;
	
	//������ ��ȸ
	@RequestMapping("/list.hr")
	public String list(Model model, HttpSession session) {
		session.setAttribute("category", "hr");
		//DB���� �������� ��ȸ�ؿ� ���ȭ�鿡 ���
		model.addAttribute("list",
				service.employee_list() );
		return "employee/list";
	}
}






